import '../generated_consts.dart';

class Config {
  String beHost = backendHost;
}
