# Quotes Frontend


pub global activate webdev

Build with default parameters
`webdev build`

Build with dev parameters:
`pub run build_runner build`

